## Search Utility
In this programming assignment, you are expected to implement a command-line utility that
searches for a specific pattern in one or multiple files, similar in spirit to the UNIX
`grep` command.
